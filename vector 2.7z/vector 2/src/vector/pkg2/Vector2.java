/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vector.pkg2;

import java.util.Scanner;

/**
 *
 * @author ESTUDIANTE20
 */
public class Vector2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner (System.in);
        
        int mañao_vector=5,hitler;
        
        int [] vector =new int [mañao_vector];
        
        
        for(hitler=0;hitler<mañao_vector;hitler++){
        System.out.println("ingrese los valores para el vector");
        vector[hitler]=sc.nextInt();
           
        }
        for (int obama=0;obama<mañao_vector;obama++){
            for (int i = obama+1;i<mañao_vector;i++){
               
                if(vector[obama]>vector[i]){
                    int aux=vector[i];
                    vector[i]=vector[obama];
                    vector[obama]=aux;
                    
                }
                
            }
            
        }
        System.out.println(" el vector organizado es ");
        System.out.println(" fire in the hole ");
        for(int putin=0;putin<mañao_vector;putin++){
            System.out.println(vector[putin]);
            
        }
    }     
    
}
